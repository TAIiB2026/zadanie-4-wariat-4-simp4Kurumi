﻿using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GryController : ControllerBase
    {
        private static int _idGenerator = 1;
        private static readonly List<Gra> _gry = new()
        {
            new Gra { Id = _idGenerator++, Tytul = "Wiedźmin 3", Cena = 129.99m, DataPremiery = new DateTime(2015, 5, 19) },
            new Gra { Id = _idGenerator++, Tytul = "Cyberpunk 2077", Cena = 199.99m, DataPremiery = new DateTime(2020, 12, 10) },
            new Gra { Id = _idGenerator++, Tytul = "Minecraft", Cena = 89.99m, DataPremiery = new DateTime(2011, 11, 18) },
            new Gra { Id = _idGenerator++, Tytul = "Grand Theft Auto V", Cena = 149.99m, DataPremiery = new DateTime(2013,9,17)},
            new Gra { Id = _idGenerator++, Tytul = "The Elder Scrolls V: Skyrim", Cena = 119.99m, DataPremiery = new DateTime(2011, 11, 11)}
        };

        [HttpGet]
        public IActionResult Get() => Ok(_gry);

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var gra = _gry.FirstOrDefault(g => g.Id == id);
            return gra is null ? NotFound() : Ok(gra);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Gra gra)
        {
            gra.Id = _idGenerator++;
            _gry.Add(gra);
            return Ok(gra);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Gra gra)
        {
            var istniejaca = _gry.FirstOrDefault(g => g.Id == id);
            if (istniejaca is null) return NotFound();
            istniejaca.Tytul = gra.Tytul;
            istniejaca.Cena = gra.Cena;
            istniejaca.DataPremiery = gra.DataPremiery;
            return Ok(istniejaca);
        }
    }

    public class Gra
    {
        public int Id { get; set; }
        public string Tytul { get; set; } = string.Empty;
        public decimal Cena { get; set; }
        public DateTime DataPremiery { get; set; }
    }
}
