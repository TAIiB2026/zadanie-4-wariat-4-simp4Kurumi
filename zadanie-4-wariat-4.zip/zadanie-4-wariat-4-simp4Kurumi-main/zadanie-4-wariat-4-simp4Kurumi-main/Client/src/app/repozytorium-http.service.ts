import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, catchError, of } from 'rxjs';
import { GetDataInterface } from './interfaces/get-data.interface';
import { FormSubmitInterface } from './interfaces/form-submit.interface';
import { GraClass } from './classes/gra.class';

@Injectable()
export class RepozytoriumHttpService implements GetDataInterface, FormSubmitInterface {
  private readonly apiUrl = 'http://localhost:5113/api/gry';

  constructor(private readonly http: HttpClient) {}

  Get(): Observable<GraClass[]> {
    return this.http.get<GraClass[]>(this.apiUrl).pipe(
      map(items => items.map(x =>
        new GraClass(x.id, x.tytul, x.cena, new Date(x.dataPremiery))
      ))
    );
  }

  GetByID(id: number): Observable<GraClass> {
    return this.http.get<GraClass>(`${this.apiUrl}/${id}`).pipe(
      map(x => new GraClass(x.id, x.tytul, x.cena, new Date(x.dataPremiery)))
    );
  }

  Post(nazwa: string, cena: number, data: Date): Observable<boolean> {
    const body = { tytul: nazwa, cena: cena, dataPremiery: data };
    return this.http.post(this.apiUrl, body).pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }

  Put(id: number, nazwa: string, cena: number, data: Date): Observable<boolean> {
    const body = { id: id, tytul: nazwa, cena: cena, dataPremiery: data };
    return this.http.put(`${this.apiUrl}/${id}`, body).pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }
}